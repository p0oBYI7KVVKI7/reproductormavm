#librerias
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
from pymkv import MKVFile
import tkinter as tk
import subprocess
import argparse
import shutil
import time
import vlc
import os

#scripts para otros procesos
import menus
from mavm import MaVM

shutil.rmtree(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp'))   # Borra la carpeta completa
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp'))

shutil.rmtree(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp_frames'))   # Borra la carpeta completa
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp_frames'))

class ventana:
    def __init__(self, ventana_tk, file):
        #ventana
        self.ventana_tk = ventana_tk
        self.ventana_tk.title("reproductor MaVM")
        self.ventana_tk.geometry("800x450")
        self.ventana_tk.minsize(800,450)
        self.ventana_tk.config(bg='gray')


        #variables
        self.file = file
        self.raiz_proyecto = os.path.dirname(os.path.abspath(__file__))
        print(self.raiz_proyecto)
        self.carpeta_temporal = os.path.join(self.raiz_proyecto, 'temp')
        self.carpeta_temporal_frames = os.path.join(self.raiz_proyecto, 'temp_frames')


        #objetos
        #abrir un archivo
        archivos = tk.Button(self.ventana_tk, text="archivos", command=self.archivos_ventana)
        archivos.place(x=0,y=0,width=80,height=16)

        self.reproductor = tk.Frame(self.ventana_tk, bg='black')
        self.reproductor.place(x=0,y=20)

        self.atras_boton = tk.Button(self.ventana_tk, text="<-10s")
        self.atras_boton.place(x=0,y=430,width=20,height=16)

        self.adelante_boton = tk.Button(self.ventana_tk, text="10s->")
        self.adelante_boton.place(x=780,y=430,width=20,height=16)

        self.play_boton = tk.Button(self.ventana_tk, text="play/pause")
        self.play_boton.place(x=780,y=430,width=20,height=16)

        self.ventana_tk.after(50, self.actalizar_medidas)


        #codigo
        if self.file:
            self.repdorucir()
    
    def archivos_ventana(self):
        self.file = filedialog.askopenfilename(title='buscar video MaVM', filetypes=(('video MaVM', '*.mavm'),
                                                                                     ('todos los archivos', '*.*')))
        print(self.file)
        self.repdorucir()

    def actalizar_medidas(self):
        ancho_ventana = self.ventana_tk.winfo_width()
        alto_ventana = self.ventana_tk.winfo_height()
        
        interfaz_alto = max(self.ventana_tk.winfo_height()*.05,16)
        interfaz_ancho = max(self.ventana_tk.winfo_width()*.0625,50)
        play_ancho = max(self.ventana_tk.winfo_width()*.1875,150)

        self.reproductor.config(width=ancho_ventana,height=alto_ventana-(20+4+interfaz_alto))

        self.atras_boton.place(x=int(ancho_ventana/3)-interfaz_ancho/2,y=alto_ventana-interfaz_alto,width=interfaz_ancho,height=interfaz_alto)

        self.play_boton.place(x=int(ancho_ventana/2)-play_ancho/2,y=alto_ventana-interfaz_alto,width=play_ancho,height=interfaz_alto)

        self.adelante_boton.place(x=int(2*ancho_ventana/3)-interfaz_ancho/2,y=alto_ventana-interfaz_alto,width=interfaz_ancho,height=interfaz_alto)

        self.ventana_tk.after(10, self.actalizar_medidas)

    def menu(self, videos):
        #crear canvas y scrollbar
        self.menu_var = tk.Canvas(self.reproductor, background="black")
        self.barra_de_subir_bajar = tk.Scrollbar(self.reproductor, orient="vertical", command=self.menu_var.yview)
        self.menu_var.configure(yscrollcommand=self.barra_de_subir_bajar.set)

        #empaquetar canvas y scrollbar
        self.menu_var.pack(side="left", fill="both", expand=True)
        self.barra_de_subir_bajar.pack(side="right", fill="y")

        #crear frame dentro del canvas
        self.menu_frame = tk.Frame(self.menu_var, background="black")
        self.menu_var.create_window((0, 0), window=self.menu_frame, anchor="nw")

        #agregar botones al frame
        for video in videos:
            boton = tk.Button(self.menu_frame, text=f"video: {video['title']}",
                            command=lambda path=video['path']: self.video(path))
            boton.pack(fill="x", padx=5, pady=2)

        #actualizar scrollregion cuando el frame cambie
        self.menu_frame.bind("<Configure>", lambda e: self.menu_var.configure(scrollregion=self.menu_var.bbox("all")))

    def repdorucir(self):
        videos = MaVM.extrac_type_all(file=self.file, output_folder=self.carpeta_temporal, content_type="video/x-matroska")

        videos_dat = []
        for video in videos:
            directorio, archivo = os.path.split(video)
            nombre, extension = os.path.splitext(archivo)
            videos_dat.append({'title': nombre, 'path':video})
            print(MKVFile(video))
        self.menu(videos_dat)

    def video(self,video_path):
        subprocess.run(['mpv', video_path])
        #def resize_image(frame, imagen_file, imagen):
        #    frame_alto = frame.width
        #    frame_alto = frame.height

#            imagen_ratio = imagen_file.width / imagen_filen.height
#            frame_ratio = frame_alto / frame_alto
#
#            if frame_ratio > imagen_ratio:
#                altura_final = frame_alto
#                ancho_final = int(altura_final * imagen_ratio)
#            else:
#                ancho_final = frame_alto
#                altura_final = int(ancho_final / imagen_ratio)

            #redimensionar la imagen
#            image_redimecionado = imagen_file.resize((ancho_final, altura_final), Image.LANCZOS)
#            tk_imagen = ImageTk.PhotoImage(image_redimecionado)

            #actualizar la etiqueta
#            imagen.config(image=tk_image)
#            imagen.image = tk_image  #evitar que se libere la referencia


#        video_capture = cv2.VideoCapture(video_path)
#        if not video_capture.isOpened():
#            print("No se pudo abrir el video")
#        else:
#            segundos_por_fotograma = 1/video_capture.get(cv2.CAP_PROP_FPS)

#            for widget in self.reproductor.winfo_children():
#                widget.destroy()  # elimina cada widget
            
#            imagen = tk.Label(self.reproductor, bg="black")
#            imagen.pack(fill="both", expand=True)

#            while True:
                #guardar cada fotograma como imagen
#                frame_filename = os.path.join(output_folder, f"frame_{frame_number:04d}.png")
#                print('d')
#                ffmpeg.input(video_path, ss=0).output(frame_filename, vframe=frame_number)
#                print('p')

#                imagen_file = Image.open(f"frame_{frame_number:04d}.png")

#                frame_number += 1
#                for i in range(1,50):
#                    time.sleep(segundos_por_fotograma/50)
#                    resize_image(frame,imagen_file,imagen)


def args():
    parser = argparse.ArgumentParser(description="reproductor MaVM")
    parser.add_argument("file", nargs='?', help="ruta del video .mavm")
    
    args_var = parser.parse_args()
    
    if args_var.file:
        if not('.mavm' in args_var.file.lower()):
            print("el archivo debe ser .mavm")
            exit()
        elif not(os.path.exists(args_var.file)):
            print("el archivo no existe")
            exit()
        else:
            file = os.path.abspath(args_var.file)
            ventana_tk = tk.Tk()
            ventana(ventana_tk=ventana_tk, file=file)
            ventana_tk.mainloop()
    else:
        ventana_tk = tk.Tk()
        ventana(ventana_tk, None)
        ventana_tk.mainloop()

args()